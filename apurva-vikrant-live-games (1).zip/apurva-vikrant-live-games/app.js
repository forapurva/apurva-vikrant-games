import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
  getDatabase, ref, set, get, update, onValue, remove, onDisconnect
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-database.js";

/*
  1) Create a Firebase project at https://console.firebase.google.com/
  2) Add a Web App and paste its config below.
  3) Enable Realtime Database.
  4) For a private prototype, use the database rules shown in README.md.
*/

const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://PASTE_YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "PASTE_YOUR_PROJECT",
  storageBucket: "PASTE_YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};

const $ = id => document.getElementById(id);
const screens = {setup:$("setup"), lobby:$("lobby"), game:$("game"), result:$("result")};
let db = null, roomCode = null, role = null, roomRef = null, unsubscribe = null;
let localState = { rpsChoice:null, reactionStart:0 };

function configured(){
  return !firebaseConfig.apiKey.startsWith("PASTE_") && firebaseConfig.databaseURL.includes("firebaseio.com");
}
function show(name){ Object.values(screens).forEach(x=>x.classList.add("hidden")); screens[name].classList.remove("hidden"); }
function setConnection(t){ $("connection").textContent=t; }
function cleanCode(v){ return (v||"").replace(/\D/g,"").slice(0,6); }
function randomCode(){ return String(Math.floor(100000 + Math.random()*900000)); }
function playerName(r){ return r==="apurva" ? "Apurva" : "Vikrant"; }
function other(r){ return r==="apurva" ? "vikrant" : "apurva"; }

async function connectFirebase(){
  if(!configured()){ setConnection("Add Firebase config"); return false; }
  try{
    const app = initializeApp(firebaseConfig);
    db = getDatabase(app);
    setConnection("Online");
    return true;
  }catch(e){ console.error(e); setConnection("Connection error"); return false; }
}

function roomData(){
  return {
    apurva:{ready:false,online:true},
    vikrant:{ready:false,online:true},
    game:null,
    phase:"lobby",
    round:0
  };
}

async function createRoom(){
  if(!db && !(await connectFirebase())) return;
  roomCode = randomCode(); role="apurva"; roomRef=ref(db,"rooms/"+roomCode);
  const exists = await get(roomRef);
  if(exists.exists()){ createRoom(); return; }
  await set(roomRef,roomData());
  await update(ref(db,`rooms/${roomCode}/apurva`),{online:true});
  onDisconnect(ref(db,`rooms/${roomCode}/apurva/online`)).set(false);
  enterRoom();
}
async function joinRoom(){
  if(!db && !(await connectFirebase())) return;
  const code=cleanCode($("roomInput").value);
  if(code.length!==6){ $("roomInfo").textContent="Enter the 6-digit room code."; return; }
  const r=ref(db,"rooms/"+code), snap=await get(r);
  if(!snap.exists()){ $("roomInfo").textContent="Room not found."; return; }
  const data=snap.val();
  if(data.vikrant?.online){ $("roomInfo").textContent="That room already has two players."; return; }
  roomCode=code; role="vikrant"; roomRef=r;
  await update(ref(db,`rooms/${roomCode}/vikrant`),{online:true,ready:false});
  onDisconnect(ref(db,`rooms/${roomCode}/vikrant/online`)).set(false);
  enterRoom();
}
function enterRoom(){
  $("roomCodeLabel").textContent=roomCode;
  $("roomInfo").textContent=`Room ${roomCode} created. Send the code to the other player.`;
  show("lobby");
  if(unsubscribe) unsubscribe();
  unsubscribe=onValue(roomRef,s=>{ if(s.exists()) renderRoom(s.val()); });
}
function renderRoom(d){
  const a=d.apurva||{}, v=d.vikrant||{};
  $("lobbyApurva").textContent=a.online ? (a.ready?"Ready ✓":"Connected") : "Waiting";
  $("lobbyVikrant").textContent=v.online ? (v.ready?"Ready ✓":"Connected") : "Waiting";
  $("apurvaStatus").textContent=a.online?"Connected":"Waiting";
  $("vikrantStatus").textContent=v.online?"Connected":"Waiting";
  const both=!!a.online&&!!v.online;
  $("readyBtn").disabled=!both;
  $("readyBtn").textContent=d[role]?.ready ? "Ready ✓" : "I'm Ready";
  $("gamePicker").classList.toggle("hidden",!(a.ready&&v.ready));
  if(d.phase==="game" && d.game){ show("game"); renderGame(d); }
  if(d.phase==="result" && d.result){ showResult(d.result); }
}
$("createBtn").addEventListener("click",createRoom);
$("joinBtn").addEventListener("click",joinRoom);
$("roomInput").addEventListener("input",e=>e.target.value=cleanCode(e.target.value));
$("readyBtn").addEventListener("click",async()=>{
  await update(ref(db,`rooms/${roomCode}/${role}`),{ready:true});
});
$("leaveBtn").addEventListener("click",async()=>{
  if(roomRef) await update(ref(db,`rooms/${roomCode}/${role}`),{online:false,ready:false});
  if(unsubscribe) unsubscribe();
  roomCode=null;role=null;roomRef=null;show("setup");
});
$("backLobbyBtn").addEventListener("click",async()=>{
  await update(roomRef,{phase:"lobby",game:null,result:null});
  show("lobby");
});
document.querySelectorAll(".game-btn").forEach(b=>b.addEventListener("click",()=>startGame(b.dataset.game)));

async function startGame(game){
  const base={phase:"game",game,round:0,result:null};
  if(game==="arm") base.arm={apurva:0,vikrant:0};
  if(game==="rps") base.rps={apurva:null,vikrant:null,aScore:0,vScore:0};
  if(game==="reaction") base.reaction={phase:"waiting",startAt:0,aTime:null,vTime:null};
  await update(roomRef,base);
}

function renderGame(d){
  $("gameTitle").textContent=d.game==="arm"?"💪 Arm Wrestling":d.game==="rps"?"✊ Rock Paper Scissors":"⚡ Reaction Battle";
  if(d.game==="arm") renderArm(d);
  if(d.game==="rps") renderRps(d);
  if(d.game==="reaction") renderReaction(d);
}

function renderArm(d){
  const a=d.arm.apurva||0,v=d.arm.vikrant||0,total=Math.max(1,a+v);
  const pos=Math.max(10,Math.min(90,50+(v-a)/2));
  $("gameArea").innerHTML=`
    <div class="arm-wrap">
      <div class="arm-stage">
        <div class="arm-line"></div>
        <div class="arm-side left">Apurva</div><div class="arm-side right">Vikrant</div>
        <div class="arm-hand" style="left:${pos}%">🤝</div>
      </div>
      <div class="meter"><div style="width:${(a/(a+v||1))*100}%"></div></div>
      <p>Apurva ${a} — ${v} Vikrant</p>
      <button id="tapBtn" class="tap">TAP! 💪</button>
    </div>`;
  $("tapBtn").addEventListener("click",async()=>{
    const key=`rooms/${roomCode}/arm/${role}`;
    const snap=await get(ref(db,key)); const val=(snap.val()||0)+1;
    await set(ref(db,key),Math.min(val,100));
    if(val>=100){
      const winner=role; const loser=other(role);
      await update(roomRef,{phase:"result",result:{winner,loser,reason:"Arm Wrestling",emoji:"💪🏆"}});
    }
  });
}

const icons={rock:"✊",paper:"✋",scissors:"✌️"};
function renderRps(d){
  const r=d.rps||{}; const both=r.apurva&&r.vikrant;
  $("gameArea").innerHTML=`
    <div class="score"><strong>Apurva ${r.aScore||0}</strong><span>—</span><strong>${r.vScore||0} Vikrant</strong></div>
    <p style="text-align:center">${both?"Choices locked — revealing…":"Choose your move:"}</p>
    <div class="rps-grid">
      <button data-rps="rock" ${r[role]?"disabled":""}>✊</button>
      <button data-rps="paper" ${r[role]?"disabled":""}>✋</button>
      <button data-rps="scissors" ${r[role]?"disabled":""}>✌️</button>
    </div>`;
  document.querySelectorAll("[data-rps]").forEach(b=>b.addEventListener("click",async()=>{
    await set(ref(db,`rooms/${roomCode}/rps/${role}`),b.dataset.rps);
  }));
  if(both && !d._rpsResolving) resolveRps(d);
}
async function resolveRps(d){
  d._rpsResolving=true;
  const a=d.rps.apurva,v=d.rps.vikrant;
  if(a===v){ setTimeout(()=>update(roomRef,{rps:{...d.rps,apurva:null,vikrant:null},round:(d.round||0)+1}),700); return; }
  const win=(a==="rock"&&v==="scissors")||(a==="paper"&&v==="rock")||(a==="scissors"&&v==="paper")?"apurva":"vikrant";
  const nr={...d.rps,apurva:null,vikrant:null};
  if(win==="apurva") nr.aScore=(nr.aScore||0)+1; else nr.vScore=(nr.vScore||0)+1;
  const score=win==="apurva"?nr.aScore:nr.vScore;
  if(score>=2){
    setTimeout(()=>update(roomRef,{phase:"result",result:{winner:win,loser:other(win),reason:"Rock Paper Scissors",emoji:"✊🏆"}}),700);
  }else{
    setTimeout(()=>update(roomRef,{rps:nr,round:(d.round||0)+1}),700);
  }
}

let reactionTimer=null;
function renderReaction(d){
  const r=d.reaction||{};
  $("gameArea").innerHTML=`
    <div class="reaction">
      <p>Wait for <strong>GO!</strong> — then tap as fast as possible.</p>
      <div id="reactionBox" class="reaction-box ${r.phase==="go"?"go":r.phase==="early"?"early":""}">
        ${r.phase==="go"?"GO! ⚡":r.phase==="early"?"Too early!":"Get ready…"}
      </div>
      <button id="reactionBtn" class="tap">${r.phase==="go"?"TAP!":"Ready"}</button>
    </div>`;
  const btn=$("reactionBtn");
  if(r.phase==="waiting"){
    btn.addEventListener("click",async()=>{
      const isHost=role==="apurva";
      if(isHost){
        await update(ref(db,`rooms/${roomCode}/reaction`),{phase:"countdown",startAt:Date.now()});
        const delay=1200+Math.floor(Math.random()*2800);
        clearTimeout(reactionTimer);
        reactionTimer=setTimeout(()=>update(ref(db,`rooms/${roomCode}/reaction`),{phase:"go",startAt:Date.now()}),delay);
      }
    });
  } else if(r.phase==="go" && !r[role+"Time"]){
    btn.addEventListener("click",async()=>{
      await set(ref(db,`rooms/${roomCode}/reaction/${role}Time`),Date.now());
    });
  }
  if(r.apurvaTime && r.vikrantTime){
    const winner=r.apurvaTime<r.vikrantTime?"apurva":"vikrant";
    setTimeout(()=>update(roomRef,{phase:"result",result:{winner,loser:other(winner),reason:"Reaction Battle",emoji:"⚡🏆"}}),500);
  }
  if(r.phase==="countdown") setTimeout(()=>renderReaction({...d,reaction:{...r}}),100);
}

function showResult(res){
  show("result");
  $("resultEmoji").textContent=res.emoji||"🏆";
  $("resultTitle").textContent=`${playerName(res.winner)} wins!`;
  $("resultText").innerHTML=`${playerName(res.loser)} loses this round.<br><strong>Playful consequence: ${playerName(res.loser)} owes ${playerName(res.winner)} a kiss 💋</strong>`;
}
$("rematchBtn").addEventListener("click",async()=>{
  await update(roomRef,{phase:"lobby",result:null,game:null,round:0});
  await update(ref(db,`rooms/${roomCode}/${role}`),{ready:true});
  show("lobby");
});
$("resultGamesBtn").addEventListener("click",async()=>{
  await update(roomRef,{phase:"lobby",result:null,game:null,round:0});
  show("lobby");
});

connectFirebase();
