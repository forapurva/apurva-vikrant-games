# Apurva × Vikrant — Live 1v1 Games

This is a GitHub Pages frontend with Firebase Realtime Database for live room synchronization.

## Files

- `index.html` — game UI
- `style.css` — responsive styling
- `app.js` — multiplayer logic
- `assets/apurva.jpg` — supplied Apurva photo
- `assets/vikrant.jpg` — supplied Vikrant photo

## 1. Create the Firebase project

1. Open Firebase Console: https://console.firebase.google.com/
2. Create a new project.
3. Add a **Web App**.
4. Copy its Firebase configuration.
5. Go to **Build → Realtime Database → Create Database**.
6. Choose a nearby region and start in locked mode.
7. In `app.js`, replace the `firebaseConfig` placeholder values with your project's config.

The Firebase web configuration is okay to put in a public frontend; your database rules are what protect the data.

## 2. Realtime Database rules

For a simple prototype, you can use:

{
  "rules": {
    "rooms": {
      "$room": {
        ".read": true,
        ".write": true
      }
    }
  }
}

For a public deployment, do NOT leave these open indefinitely. Add Firebase Authentication and proper room/participant validation before sharing the site widely.

## 3. Publish with GitHub Pages

1. Create a GitHub repository, e.g. `apurva-vikrant-games`.
2. Upload everything in this folder, keeping the `assets` folder.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select `main` and `/root`.
6. Save.
7. GitHub will provide your Pages URL.

## How players use it

- Player 1 clicks **Create Room**.
- The site generates a 6-digit room code.
- Player 1 sends the code to Player 2.
- Player 2 enters the code and clicks **Join Room**.
- Both click **I'm Ready**.
- Choose a game.
- Game state is synchronized through Firebase.

## Games included

- Arm Wrestling — first to 100 power taps wins.
- Rock Paper Scissors — best of 3.
- Reaction Battle — randomized GO signal and fastest response wins.

The result screen currently uses a playful, non-explicit consequence: the loser owes the winner a kiss.

## Important

This is a prototype. The open database rules are intentionally simple so you can get the first version working quickly. For a public site, secure the database with authentication and stricter rules.
